<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <a class="btn btn-danger" href="<?php echo e(route('Supplier.create')); ?>">Create</a>
            </h3>
        </div>
    </div>
    <div class="card">

        <!-- /.card-header -->
        <div class="card-body">
            <?php echo $__env->make('AdminPanel.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(count($Suppliers) > 0): ?>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>English Name</th>
                        <th>Arabic Name</th>
                        <th>English Title</th>
                        <th>Arabic Title</th>
                        <th>Phone</th>
                        <th>image</th>
                        <th>Control</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td ><?php echo e($item->name); ?></td>
                            <td ><?php echo e($item->nameAr); ?></td>
                            <td ><?php echo e($item->title); ?></td>
                            <td ><?php echo e($item->titleAr); ?></td>
                            <td ><?php echo e($item->phone); ?></td>
                            <td><img src="<?php echo e(url($item->image)); ?>" width="150" height="100"></td>
                            <td>
                                <a class="btn btn-dark" href="<?php echo e(route('Supplier.edit',$item)); ?>">Edit</a>
                                <form action="<?php echo e(route("Supplier.destroy", $item)); ?>" method="post"
                                      style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="button" id="btnDelete" class="btn btn-danger btn-delete">Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th>English Name</th>
                        <th>Arabic Name</th>
                        <th>English Title</th>
                        <th>Arabic Title</th>
                        <th>Phone</th>
                        <th>image</th>
                        <th>Control</th>
                    </tr>
                    </tfoot>
                </table>
            <?php else: ?>
                <h1 class="text-center">NO DATA</h1>
            <?php endif; ?>
        </div>
        <!-- /.card-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ecommerce\resources\views/AdminPanel/Supplier/index.blade.php ENDPATH**/ ?>