<?php $__env->startSection('content'); ?>


    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('adminDashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(isset($Supplier)?'Edit '.$Supplier->name :'ADD'); ?></li>
                    </ol>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- jquery validation -->
                    <div class="card card-primary">

                        <!-- /.card-header -->
                        <!-- form start -->
                        <form  action="<?php echo e((isset($Supplier))?route('Supplier.update',$Supplier):route('Supplier.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo $__env->make('AdminPanel.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <?php echo e(isset($Supplier)?method_field('PUT'):''); ?>

                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name">English Name</label>
                                    <input type="text" name="name" class="form-control"
                                           placeholder="Enter Name" value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php elseif(isset($Supplier->name)): ?><?php echo e($Supplier->name); ?><?php endif; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="name">Arabic Name</label>
                                    <input type="text" name="nameAr" class="form-control"
                                           placeholder="Enter Name" value="<?php if(old('nameAr')): ?><?php echo e(old('nameAr')); ?><?php elseif(isset($Supplier->nameAr)): ?><?php echo e($Supplier->nameAr); ?><?php endif; ?>" required>
                                </div>


                                <div class="form-group">
                                    <label for="title">English title</label>
                                    <input type="text" name="title" class="form-control"
                                           placeholder="Enter Name" value="<?php if(old('title')): ?><?php echo e(old('title')); ?><?php elseif(isset($Supplier->title)): ?><?php echo e($Supplier->title); ?><?php endif; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="titleAr">Arabic title</label>
                                    <input type="text" name="titleAr" class="form-control"
                                           placeholder="Enter Name" value="<?php if(old('titleAr')): ?><?php echo e(old('titleAr')); ?><?php elseif(isset($Supplier->titleAr)): ?><?php echo e($Supplier->titleAr); ?><?php endif; ?>" required>
                                </div>


                                <div class="form-group">
                                    <label for="image">Image</label>
                                    <input type="file" class="form-control" name="image" <?php if(!isset($Supplier)): ?>required <?php endif; ?>>
                                    <br>
                                    <?php if(isset($Supplier->image)): ?>
                                        <img src="<?php echo e(url($Supplier->image)); ?>" width="250" height="250">
                                    <?php endif; ?>
                                </div>


                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input type="text" class="form-control" name="phone" value="<?php if(old('phone')): ?><?php echo e(old('phone')); ?><?php elseif(isset($Supplier->phone)): ?><?php echo e($Supplier->phone); ?><?php endif; ?>">
                                </div>

                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (left) -->
                <!-- right column -->
                <div class="col-md-6">

                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ecommerce\resources\views/AdminPanel/Supplier/form.blade.php ENDPATH**/ ?>