<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <a class="btn btn-danger" href="<?php echo e(route('SubCategory.create')); ?>">Create</a>
            </h3>
        </div>
    </div>
    <div class="card">

        <!-- /.card-header -->
        <div class="card-body">
            <?php echo $__env->make('AdminPanel.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(count($SubCategories) > 0): ?>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>English Name</th>
                        <th>Arabic Name</th>
                        <th>image</th>
                        <th>Status</th>
                        <th>Display Order</th>
                        <th>Main Category</th>
                        <th>Control</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $SubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td ><?php echo e($item->name); ?></td>
                            <td ><?php echo e($item->nameAr); ?></td>
                            <td><img src="<?php echo e(url($item->image)); ?>" width="150" height="100"></td>
                            <td> <a  style="color: #ffffff" href="<?php echo e(route('changeStatusSubCategory',$item)); ?>" class="btn <?php echo e(($item->isActive)?'btn-danger':'btn-primary'); ?> text-center"><?php echo e(($item->isActive)?'Set Hide':'set Active'); ?></a></td>
                            <td ><?php echo e($item->displayOrder); ?></td>
                            <td ><?php echo e($item->mainCategory->name); ?></td>
                            <td>
                                <a class="btn btn-dark" href="<?php echo e(route('SubCategory.edit',$item)); ?>">Edit</a>
                                <form action="<?php echo e(route("SubCategory.destroy", $item)); ?>" method="post"
                                      style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="button" id="btnDelete" class="btn btn-danger btn-delete">Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th>English Name</th>
                        <th>Arabic Name</th>
                        <th>image</th>
                        <th>Status</th>
                        <th>Display Order</th>
                        <th>Main Category</th>
                        <th>Control</th>
                    </tr>
                    </tfoot>
                </table>
            <?php else: ?>
                <h1 class="text-center">NO DATA</h1>
            <?php endif; ?>
        </div>
        <!-- /.card-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ecommerce\resources\views/AdminPanel/SubCategory/index.blade.php ENDPATH**/ ?>