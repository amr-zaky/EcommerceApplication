<?php $__env->startSection('content'); ?>


    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('adminDashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo e(isset($SubCategory)?'Edit '.$SubCategory->name :'ADD'); ?></li>
                    </ol>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- jquery validation -->
                    <div class="card card-primary">

                        <!-- /.card-header -->
                        <!-- form start -->
                        <form  action="<?php echo e((isset($SubCategory))?route('SubCategory.update',$SubCategory):route('SubCategory.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo $__env->make('AdminPanel.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <?php echo e(isset($SubCategory)?method_field('PUT'):''); ?>

                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name">English Name</label>
                                    <input type="text" name="name" class="form-control"
                                           placeholder="Enter Name" value="<?php if(old('name')): ?><?php echo e(old('name')); ?><?php elseif(isset($SubCategory->name)): ?><?php echo e($SubCategory->name); ?><?php endif; ?>" required>
                                </div>

                                <div class="form-group">
                                    <label for="name">Arabic Name</label>
                                    <input type="text" name="nameAr" class="form-control"
                                           placeholder="Enter Name" value="<?php if(old('nameAr')): ?><?php echo e(old('nameAr')); ?><?php elseif(isset($SubCategory->nameAr)): ?><?php echo e($SubCategory->nameAr); ?><?php endif; ?>" required>
                                </div>


                                <div class="form-group">
                                    <label for="image">Image</label>
                                    <input type="file" class="form-control" name="image" <?php if(!isset($SubCategory)): ?>required <?php endif; ?>>
                                    <br>
                                    <?php if(isset($SubCategory->image)): ?>
                                        <img src="<?php echo e(url($SubCategory->image)); ?>" width="250" height="250">
                                    <?php endif; ?>
                                </div>


                                <div class="form-group">
                                    <label for="name"> Main Category</label>
                                    <select id="mainCategoryId" class="form-control" name="mainCategoryId">
                                        <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mainCategory->id); ?>" <?php if(isset($SubCategory->mainCategory->id)&& $SubCategory->mainCategory->id==$mainCategory->id): ?>selected <?php endif; ?>><?php echo e($mainCategory->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="view_order">View Order</label>
                                    <input type="number" class="form-control" name="displayOrder" value="<?php if(old('displayOrder')): ?><?php echo e(old('displayOrder')); ?><?php elseif(isset($SubCategory->displayOrder)): ?><?php echo e($SubCategory->displayOrder); ?><?php endif; ?>">
                                </div>

                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (left) -->
                <!-- right column -->
                <div class="col-md-6">

                </div>
                <!--/.col (right) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminPanel.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ecommerce\resources\views/AdminPanel/SubCategory/form.blade.php ENDPATH**/ ?>